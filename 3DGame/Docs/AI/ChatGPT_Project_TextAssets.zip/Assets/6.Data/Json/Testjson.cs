using UnityEngine;

public class Testjson : MonoBehaviour
{

    void Start()
    {
        TestSaveData data = new TestSaveData();
        data.playerName = "Hero";
        data.level = 1;
        data.gold = 200;
        data.exp = 50f;

        // ���� // �����ڵ�
        string jsonDataString = JsonUtility.ToJson(data, true);
        Debug.Log(jsonDataString);
        // �ε�
        TestSaveData loadData = JsonUtility.FromJson<TestSaveData>(jsonDataString);

        Debug.Log(Application.persistentDataPath);
    }

}
