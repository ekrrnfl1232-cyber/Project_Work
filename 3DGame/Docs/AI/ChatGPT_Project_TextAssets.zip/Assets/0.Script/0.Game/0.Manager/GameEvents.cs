using System;
using UnityEngine;

public static class GameEvents
{
    // Action = �Ϲ��Լ�(), Action<�ڷ���> = �Ű��Լ�(����)

    public static Action OnQuestChanged;
    // �÷��̾ ���� ��������� �̺�Ʈ
    public static Action<MonsterData, int, float> PlayerKill;
    public static Action DeadMonster;
    public static Action<int, float> ChangeCurrency;
    public static Action ChangeEXPUpdate;
    // �÷��̾ ������ ���� ��
    public static Action<Transform> EnPlayer;
    public static Action<Transform> SpawnMonster;
    public static Action<Transform> ChaseMonster;
    public static Action ClearCombat;
    public static Action DeadPlayer;

    public static void RaiseQuestChanged()
    {
        OnQuestChanged?.Invoke();
    }

    public static void RaiseKillChange(MonsterData data, int gold, float exp)
    {
        PlayerKill?.Invoke(data, gold, exp);
    }

    public static void RaiseChangeDeadMonster()
    {
        DeadMonster?.Invoke();
    }

    public static void RaiseChangeCurrency(int gold, float exp)
    {
        ChangeCurrency?.Invoke(gold, exp);
    }

    public static void RaiseChangeEXPUpdate()
    {
        ChangeEXPUpdate?.Invoke();
    }

    public static void RaiseChangeEnPlayer(Transform combat)
    {
        EnPlayer?.Invoke(combat);
    }

    public static void RaiseChangeSpawnMonster(Transform mon)
    {
        SpawnMonster?.Invoke(mon);
    }

    public static void RaiseChaseMonster(Transform target)
    {
        ChaseMonster?.Invoke(target);
    }

    public static void RaiseClearCombat()
    {
        ClearCombat?.Invoke();
    }

    public static void RaiseChangeDeadPlayer()
    {
        DeadPlayer?.Invoke();
    }
}
