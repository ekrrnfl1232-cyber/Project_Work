using UnityEngine;

public class NPC : MonoBehaviour, IInterectable
{
    public void Interact()
    {
        Debug.Log("��ȭ");
    }
}
