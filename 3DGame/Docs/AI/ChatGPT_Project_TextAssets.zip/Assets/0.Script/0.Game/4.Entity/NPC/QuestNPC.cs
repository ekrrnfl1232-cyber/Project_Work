using TMPro;
using UnityEngine;

public class QuestNPC : MonoBehaviour, IInterectable
{
    [SerializeField] private QuestData questData;
    [SerializeField] private QuestManager questManager;

    [SerializeField] private GameObject questUI;
    [SerializeField] private TMP_Text questTitle;
    [SerializeField] private TMP_Text questInfo;


    private void Awake()
    {
        questUI.SetActive(false);

    }

    public string GetInterfaction()
    {
        QuestProgress quest = questManager.GetQuest(questData.questId);
        if (quest == null)
            return "[F] ����Ʈ�ޱ�";
        if (quest.State == QuestState.canComplete)
            return "[F] ����Ʈ �Ϸ�";
        if (quest.State == QuestState.Inprogress)
            return $"[F]���൵:{quest.CurrentCount}/{questData.requiredCount}";

        return "[F] ��ȭ�ϱ�";
    }
    public void Interact()
    {
        QuestProgress quest = questManager.GetQuest(questData.questId);
        if (quest == null)
        {
            questTitle.text = $"{questData.questTitle}";
            questInfo.text = $"{questData.description} \n ���� : {questData.rewardItem.name} ����ġ : {questData.rewardExp}";
            questUI.SetActive(true);
            return;
        }
        if(quest.State == QuestState.canComplete)
        {
            questManager.CompleteQuest(questData.questId);
            return;
        }
        Debug.Log("�빫 ����");
    }

    public void Accept()
    {
        questManager.AcceptQuest(questData);
        questUI.SetActive(!questUI.activeSelf);
    }

}
